﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace задание_1.работа_со_списками
{
    class KeyVal
    {
        public int key;
        public int val;
        public KeyVal()
        {
            key = 0; val = 0;
        }
        public KeyVal(int key, int val)
        {
            this.key = key;
            this.val = val;
        }
    }
}
