﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace задание_1.работа_со_списками
{
    public partial class Form1 : Form
    {
        
        int tt;
        public Form1()
        {
            InitializeComponent();
        }

        //добавить
        private void button1_Click(object sender, EventArgs e)
        {           
            var someList = new List<int>()
            {
                2,
                1,
                5,
                4,
                3,
                12,
                10,
                8,
                9
            };
     

            // Вывод элементов списка.
            foreach (var item in someList)
            {
              listBox1.Items.Add(item.ToString());
            }

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        //сортировать
        private void button4_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            var someList = new List<int>()
            {
                2,
                1,
                5,
                4,
                3,
                12,
                10,
                8,
                9
            };

            // Сортировка списка.
            someList.Sort();

            // Вывод элементов списка.
            foreach (var item in someList)
            {
                // Console.WriteLine(item);
                listBox1.Items.Add(item.ToString());
            }

        }

        //удалить все элементы
        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

        }

        //отобразить список
        private void button5_Click(object sender, EventArgs e)
        {
            var someList = new List<int>()
            {
                2,
                1,
                5,
                4,
                3,
                12,
                10,
                8,
                9
            };

            KeyVal[] x;
            int n = 13;
            var init = Enumerable.Range(0, n).OrderBy(b => someList).ToArray();
            x = new KeyVal[n];
            for (int i = 0; i < init.Length; i++)
            {
                x[i] = new KeyVal(i, init[i]);
            }

            tt = x[0].val;
            x[n / 2].val = x[0].val;
            x[n - 6].val = x[0].val;
            x[n - 2].val = x[0].val;
            chart1.Series[0].Points.Clear();
            chart1.ChartAreas[0].AxisX.Minimum = 0;
            chart1.ChartAreas[0].AxisX.Maximum = n;
            for (int i = 0; i != n; i++)
            {
                chart1.Series[0].Points.AddXY(i, x[i].val);
               
            }
        }

        //удалить первый элемент
        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Remove(listBox1.Items[0]);
        }
    }
}
